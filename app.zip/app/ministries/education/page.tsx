// app/ministries/education/page.tsx
export default function EducationMinistryPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-4">교육사역</h1>
      <p className="text-slate-500">현재 표시할 교육사역 게시물이 없습니다.</p>
    </div>
  );
}
