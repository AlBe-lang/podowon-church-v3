// app/worship/wed/page.tsx
export default function WedWorshipPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-4">수요예배</h1>
      <p className="text-slate-500">현재 등록된 예배 자료가 없습니다.</p>
    </div>
  );
}
