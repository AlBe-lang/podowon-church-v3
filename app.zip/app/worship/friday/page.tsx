// app/worship/friday/page.tsx
export default function FridayPrayerPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-4">금요기도회</h1>
      <p className="text-slate-500">현재 등록된 콘텐츠가 없습니다.</p>
    </div>
  );
}
