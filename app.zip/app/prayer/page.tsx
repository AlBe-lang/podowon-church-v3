// app/prayer/page.tsx
export default function PrayerPage() {
  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-4">기도제목</h1>
      <p className="text-slate-500">등록된 기도제목이 없습니다.</p>
    </div>
  );
}
